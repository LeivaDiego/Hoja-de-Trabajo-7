/**
 * Interfaz para el recorrido del arbol
 * @author diego LEIVA
 *
 * Referencia de MalonsoUVG
 */
public interface ITreeTraversal<V> {

	void Walk(V value);
	
}
